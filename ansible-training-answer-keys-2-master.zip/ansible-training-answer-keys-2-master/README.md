# ansible-training-answer-keys-2

This is the answer key for coding exercises on the Udemy Course - https://www.udemy.com/learn-ansible-advanced

